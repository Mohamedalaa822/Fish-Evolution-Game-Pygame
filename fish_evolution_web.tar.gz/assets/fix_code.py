import shutil
import re

# copy original
shutil.copy('C:/Users/RO~/Downloads/fish_evolution.py', 'C:/Users/RO~/.gemini/antigravity/scratch/fish_evolution_web/main.py')

with open('C:/Users/RO~/.gemini/antigravity/scratch/fish_evolution_web/main.py', 'r', encoding='utf-8') as f:
    code = f.read()

# Replace numpy
code = code.replace('import numpy as np', 'import asyncio')

# Find and replace sound generation using regex to avoid box chars
sound_gen_pattern = re.compile(r'# ── Sound generation ──+.*?powerup_sound.*?wave="sine"\)', re.DOTALL)
sound_load_str = '''# ── Sound Loading ─────────────────────────────────────────────────────────
try:
    eat_sound      = pygame.mixer.Sound("eat.wav")
    level_sound    = pygame.mixer.Sound("level.wav")
    gameover_sound = pygame.mixer.Sound("gameover.wav")
    powerup_sound  = pygame.mixer.Sound("powerup.wav")
except:
    class DummySound:
        def play(self): pass
    eat_sound = level_sound = gameover_sound = powerup_sound = DummySound()'''

code = sound_gen_pattern.sub(sound_load_str, code)

# Rewrite game loop
loop_start = '''high_score   = 0
boss_spawned = False
particles    = []
floats       = []
reset_game()
state   = "start"
running = True

while running:'''

main_str = '''async def main():
    global high_score, boss_spawned, particles, floats, state, running, player, enemies, bubbles, powerups, boss, level, game_over, paused, spawn_timer, powerup_timer
    
    high_score   = 0
    boss_spawned = False
    particles    = []
    floats       = []
    reset_game()
    state   = "start"
    running = True

    while running:'''

code = code.replace(loop_start, main_str)

# Add awaits. We need to add await asyncio.sleep(0) after pygame.display.update()
code = code.replace('        pygame.display.update()\n        continue', '        pygame.display.update()\n        await asyncio.sleep(0)\n        continue')
code = code.replace('    pygame.display.update()\n\npygame.quit()', '    pygame.display.update()\n        await asyncio.sleep(0)\n\n    pygame.quit()')

# Indent the body of the while loop.
lines = code.split('\n')
in_loop = False
for i in range(len(lines)):
    if '    while running:' in lines[i]:
        in_loop = True
        continue
    
    if in_loop and '    pygame.quit()' in lines[i]:
        in_loop = False
        
    if in_loop:
        if lines[i].strip():
            lines[i] = '    ' + lines[i]

code = '\n'.join(lines)

# Fix the end
code = code.replace('    pygame.quit()\nsys.exit()', '''    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())''')

with open('C:/Users/RO~/.gemini/antigravity/scratch/fish_evolution_web/main.py', 'w', encoding='utf-8') as f:
    f.write(code)
