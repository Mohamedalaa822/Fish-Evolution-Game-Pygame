import wave
import math
import struct
import random

def create_wav(filename, freq=440, duration=0.12, vol=0.4, wave_type="sine", decay=True):
    sr = 44100
    n = int(sr * duration)
    with wave.open(filename, 'w') as f:
        f.setnchannels(2)
        f.setsampwidth(2) # 16-bit
        f.setframerate(sr)
        
        for i in range(n):
            t = float(i) / sr
            if wave_type == "sine":
                w = math.sin(2 * math.pi * freq * t)
            elif wave_type == "square":
                w = 1.0 if math.sin(2 * math.pi * freq * t) > 0 else -1.0
            else: # noise
                w = random.uniform(-1, 1)
                
            if decay:
                w *= (1.0 - (i / n))
                
            v = int(w * vol * 32767)
            # pack as little-endian 16-bit stereo (left, right)
            data = struct.pack('<hh', v, v)
            f.writeframesraw(data)

create_wav("eat.wav", freq=520, duration=0.10, vol=0.35, wave_type="sine")
create_wav("level.wav", freq=700, duration=0.25, vol=0.45, wave_type="sine")
create_wav("gameover.wav", freq=150, duration=0.55, vol=0.5, wave_type="square")
create_wav("powerup.wav", freq=880, duration=0.20, vol=0.4, wave_type="sine")
