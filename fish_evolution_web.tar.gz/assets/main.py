import pygame
import random
import sys
import math
import asyncio

pygame.init()
pygame.mixer.pre_init(44100, -16, 1, 512)
pygame.mixer.init(44100, -16, 1, 512)

WIDTH, HEIGHT = 1280, 720
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Fish Evolution")
pygame.mouse.set_visible(False)  # hide cursor completely

clock = pygame.time.Clock()
FPS = 60

WHITE     = (255, 255, 255)
DARK_BLUE = (0,   40,  80)
GREEN     = (34, 180,  80)
RED       = (220,  50,  50)
YELLOW    = (255, 210,  40)
PURPLE    = (160,  60, 240)
CYAN      = ( 60, 210, 210)
ORANGE    = (255, 140,  20)

font_big   = pygame.font.SysFont("Arial", 40, bold=True)
font_med   = pygame.font.SysFont("Arial", 28, bold=True)
font_small = pygame.font.SysFont("Arial", 20)

# ── Sound Loading ─────────────────────────────────────────────────────────
try:
    eat_sound      = pygame.mixer.Sound("eat.wav")
    level_sound    = pygame.mixer.Sound("level.wav")
    gameover_sound = pygame.mixer.Sound("gameover.wav")
    powerup_sound  = pygame.mixer.Sound("powerup.wav")
except:
    class DummySound:
        def play(self): pass
    eat_sound = level_sound = gameover_sound = powerup_sound = DummySound()

# ── Realistic fish renderer ───────────────────────────────────────────────────
def draw_fish(surf, cx, cy, sz, body_col, facing_right=True, t=0, fin_col=None):
    """
    Draw a detailed, realistic fish.
    sz  = half body length
    t   = time counter for tail waggle
    """
    f = 1 if facing_right else -1
    bw = sz * 2
    bh = int(sz * 0.72)

    if fin_col is None:
        fin_col = tuple(max(0, c - 70) for c in body_col)
    dark  = fin_col
    mid   = tuple(max(0,  c - 35) for c in body_col)
    light = tuple(min(255,c + 70) for c in body_col)

    # ── Tail (caudal fin) – forked ──
    tw  = int(sz * 0.75)
    tox = int(math.sin(t) * sz * 0.38)
    toy = int(math.sin(t) * sz * 0.22)
    tx  = cx - f * sz
    fork_top = [
        (tx, cy + tox),
        (tx - f*tw, cy - int(sz*0.55) + toy),
        (tx - f*int(tw*0.55), cy + tox),
    ]
    fork_bot = [
        (tx, cy + tox),
        (tx - f*tw, cy + int(sz*0.55) + toy),
        (tx - f*int(tw*0.55), cy + tox),
    ]
    pygame.draw.polygon(surf, dark,  fork_top)
    pygame.draw.polygon(surf, mid,   fork_bot)
    pygame.draw.lines(surf, dark, True, fork_top, 1)

    # ── Pelvic / anal fin (bottom) ──
    pf_pts = [
        (cx - f*int(sz*0.1), cy + bh//2),
        (cx + f*int(sz*0.1), cy + bh//2 + int(sz*0.42)),
        (cx + f*int(sz*0.4), cy + bh//2),
    ]
    pygame.draw.polygon(surf, dark, pf_pts)

    # ── Pectoral fin ──
    pc_pts = [
        (cx + f*int(sz*0.25), cy + bh//4),
        (cx + f*int(sz*0.55), cy + int(sz*0.52)),
        (cx + f*int(sz*0.7),  cy + int(sz*0.2)),
        (cx + f*int(sz*0.45), cy),
    ]
    pygame.draw.polygon(surf, mid, pc_pts)
    pygame.draw.lines(surf, dark, True, pc_pts, 1)

    # ── Main body ──
    body_rect = pygame.Rect(cx - sz, cy - bh//2, bw, bh)
    pygame.draw.ellipse(surf, body_col, body_rect)

    # ── Belly gradient (lighter) ──
    belly = pygame.Rect(cx - int(sz*0.75), cy + bh//6, int(sz*1.5), bh//3)
    belly_surf = pygame.Surface((belly.width, belly.height), pygame.SRCALPHA)
    pygame.draw.ellipse(belly_surf, (*light, 100), (0,0,belly.width,belly.height))
    surf.blit(belly_surf, belly.topleft)

    # ── Iridescent sheen (top half) ──
    sheen_rect = pygame.Rect(cx - int(sz*0.8), cy - bh//2, int(sz*1.6), bh//2)
    sheen_surf = pygame.Surface((sheen_rect.width, sheen_rect.height), pygame.SRCALPHA)
    pygame.draw.ellipse(sheen_surf, (255, 255, 255, 35), (0,0,sheen_rect.width,sheen_rect.height))
    surf.blit(sheen_surf, sheen_rect.topleft)

    # ── Scales (arc pattern) ──
    scale_col = (*dark, 120)
    for row in range(2):
        for col in range(4):
            sx = cx + f * int(sz * (-0.55 + col * 0.28))
            sy = cy - bh//4 + row * bh//3
            sr = int(sz * 0.22)
            s = pygame.Surface((sr*2, sr*2), pygame.SRCALPHA)
            pygame.draw.arc(s, scale_col,
                            (0, 0, sr*2, sr*2),
                            math.radians(30), math.radians(150), 1)
            surf.blit(s, (sx - sr, sy - sr))

    # ── Lateral line ──
    for i in range(7):
        lx = cx + f * int(sz * (-0.6 + i * 0.2))
        ly = cy - bh//8
        pygame.draw.circle(surf, dark, (lx, ly), 1)

    # ── Dorsal fin ──
    dh = int(sz * 0.62)
    d_pts = [
        (cx - f*int(sz*0.05), cy - bh//2),
        (cx + f*int(sz*0.15), cy - bh//2 - dh),
        (cx + f*int(sz*0.45), cy - bh//2 - int(dh*0.55)),
        (cx + f*int(sz*0.65), cy - bh//2),
    ]
    pygame.draw.polygon(surf, mid, d_pts)
    # Fin rays
    for i in range(3):
        fx = cx + f * int(sz*(0.05 + i*0.2))
        fy_top = cy - bh//2 - int(dh * (0.7 - i*0.12))
        pygame.draw.line(surf, dark, (fx, cy - bh//2), (fx, fy_top), 1)
    pygame.draw.lines(surf, dark, False, d_pts, 1)

    # ── Outline ──
    pygame.draw.ellipse(surf, dark, body_rect, 2)

    # ── Eye ──
    ex = int(cx + f * int(sz * 0.65))
    ey = int(cy - bh // 7)
    er = max(3, int(sz * 0.17))
    pygame.draw.circle(surf, (240, 240, 240), (ex, ey), er)
    pygame.draw.circle(surf, (15, 15, 25),    (ex + f, ey), max(2, er - 1))
    pygame.draw.circle(surf, (255,255,255),   (ex + f - 1, ey - 1), max(1, er // 3))
    pygame.draw.circle(surf, (80, 80, 200),   (ex + f, ey), max(2, er-1), 1)

    # ── Mouth ──
    mx2 = int(cx + f * sz) - f * 2
    pygame.draw.arc(surf, dark,
                    pygame.Rect(mx2 - 5, cy - 2, 8, 6),
                    0, math.pi * (1 if facing_right else 1), 1)


def draw_shark(surf, cx, cy, sz, t=0):
    col   = (75, 85, 95)
    belly = (195, 205, 210)
    dark  = (40, 50, 58)
    bw = sz * 2
    bh = int(sz * 0.58)

    # Tail
    tw = int(sz * 0.85)
    tox = int(math.sin(t) * sz * 0.28)
    tx = cx + sz
    pygame.draw.polygon(surf, dark, [
        (tx, cy + tox),
        (tx+tw, cy - int(sz*0.65)+tox),
        (tx+int(tw*0.5), cy+tox),
    ])
    pygame.draw.polygon(surf, col, [
        (tx, cy + tox),
        (tx+tw, cy + int(sz*0.65)+tox),
        (tx+int(tw*0.5), cy+tox),
    ])

    # Pectoral fins
    pygame.draw.polygon(surf, dark, [
        (cx - int(sz*0.1), cy+bh//3),
        (cx + int(sz*0.3), cy+int(sz*0.55)),
        (cx + int(sz*0.5), cy+bh//5),
    ])

    # Body
    body_rect = pygame.Rect(cx - sz, cy - bh//2, bw, bh)
    pygame.draw.ellipse(surf, col, body_rect)
    # Belly
    b_rect = pygame.Rect(cx - int(sz*0.8), cy, int(sz*1.6), bh//3)
    pygame.draw.ellipse(surf, belly, b_rect)

    # Dorsal fin
    pygame.draw.polygon(surf, dark, [
        (cx - int(sz*0.15), cy - bh//2),
        (cx - int(sz*0.4),  cy - bh//2 - int(sz*0.8)),
        (cx + int(sz*0.25), cy - bh//2),
    ])

    pygame.draw.ellipse(surf, dark, body_rect, 2)

    # Eye
    pygame.draw.circle(surf, (10,10,10), (int(cx - sz*0.6), int(cy - bh//7)), max(4, int(sz*0.1)))

    # Teeth
    for i in range(6):
        tx2 = int(cx - sz + 8 + i * int(sz * 0.14))
        pygame.draw.polygon(surf, WHITE, [
            (tx2,              cy + bh//2 - 1),
            (tx2+int(sz*0.06), cy + bh//2 + int(sz*0.17)),
            (tx2+int(sz*0.12), cy + bh//2 - 1),
        ])

    # Health bar
    bar_w = sz * 2
    bx, by = int(cx) - sz, int(cy) - sz - 22
    pygame.draw.rect(surf, RED,   (bx, by, bar_w, 10))
    pygame.draw.rect(surf, GREEN, (bx, by, bar_w, 10))
    pygame.draw.rect(surf, WHITE, (bx, by, bar_w, 10), 1)


# ────────────────────────────────────────────────
class EatParticle:
    """Tiny bubble burst when eating a fish."""
    def __init__(self, x, y):
        self.x, self.y = float(x), float(y)
        self.vx = random.uniform(-3, 3)
        self.vy = random.uniform(-3, 3)
        self.r  = random.randint(3, 7)
        self.life = 1.0   # 1 → 0

    def update(self):
        self.x += self.vx
        self.y += self.vy
        self.life -= 0.07

    def draw(self):
        alpha = int(self.life * 220)
        r = max(1, int(self.r * self.life))
        surf = pygame.Surface((r*2+2, r*2+2), pygame.SRCALPHA)
        pygame.draw.circle(surf, (180, 230, 255), (r+1, r+1), r, 1)
        surf.set_alpha(alpha)
        screen.blit(surf, (int(self.x)-r-1, int(self.y)-r-1))

    @property
    def alive(self): return self.life > 0


class FloatText:
    """Score popup that floats upward."""
    def __init__(self, x, y, text, color=WHITE):
        self.x, self.y = float(x), float(y)
        self.text  = text
        self.color = color
        self.life  = 1.0

    def update(self):
        self.y   -= 1.2
        self.life -= 0.03

    def draw(self):
        alpha = int(self.life * 255)
        s = font_small.render(self.text, True, self.color)
        s.set_alpha(alpha)
        screen.blit(s, s.get_rect(center=(int(self.x), int(self.y))))

    @property
    def alive(self): return self.life > 0


# ────────────────────────────────────────────────
class Bubble:
    def __init__(self):
        self.reset()
    def reset(self):
        self.x = random.randint(0, WIDTH)
        self.y = random.randint(HEIGHT, HEIGHT + 100)
        self.r = random.randint(3, 10)
        self.s = random.uniform(0.5, 2.5)
        self.t = random.uniform(0, 6.28)
    def update(self):
        self.y -= self.s
        self.x += math.sin(self.t) * 0.4
        self.t += 0.03
        if self.y < -20: self.reset()
    def draw(self):
        pygame.draw.circle(screen, (180, 230, 255), (int(self.x), int(self.y)), self.r, 1)
        pygame.draw.circle(screen, (220, 245, 255),
                           (int(self.x)-self.r//3, int(self.y)-self.r//3), max(1,self.r//3))


# ────────────────────────────────────────────────
class Fish:
    BASE_SPEED = 12

    def __init__(self):
        self.x = float(WIDTH  // 2)
        self.y = float(HEIGHT // 2)
        self.size  = 28
        self.speed = self.BASE_SPEED
        self.score = 0
        self.coins = 0
        self.tail  = 0.0
        self.facing_right = True
        self.shield_timer = 0
        self.speed_timer  = 0

    @property
    def shield(self): return self.shield_timer > 0
    @property
    def speed_boosted(self): return self.speed_timer > 0

    def move_to_mouse(self, mx, my):
        dx = mx - self.x
        dy = my - self.y
        dist = math.hypot(dx, dy)
        if dist > 2:
            spd = min(self.speed, dist * 0.35 + 2)
            self.x += (dx / dist) * spd
            self.y += (dy / dist) * spd
            self.facing_right = dx > 0
        self.x = max(self.size, min(WIDTH  - self.size, self.x))
        self.y = max(self.size, min(HEIGHT - self.size, self.y))

    def update_powerups(self):
        if self.shield_timer > 0: self.shield_timer -= 1
        if self.speed_timer  > 0:
            self.speed_timer -= 1
            if self.speed_timer == 0:
                self.speed = self.BASE_SPEED

    def draw(self):
        self.tail += 0.22
        if self.shield:
            glow = pygame.Surface((self.size*3, self.size*3), pygame.SRCALPHA)
            pygame.draw.circle(glow, (*CYAN, 55),
                               (self.size*3//2, self.size*3//2), self.size+14)
            screen.blit(glow, (int(self.x)-self.size*3//2, int(self.y)-self.size*3//2))
            pygame.draw.circle(screen, CYAN, (int(self.x), int(self.y)), self.size+10, 2)
        draw_fish(screen, int(self.x), int(self.y),
                  self.size, GREEN, self.facing_right, self.tail)

    def get_rect(self):
        return pygame.Rect(int(self.x) - 3, int(self.y) - 3, 6, 6)


# ────────────────────────────────────────────────
FISH_PALETTES = [
    ((255,180, 30), (180,100,  0)),
    ((220, 50, 50), (140, 20, 20)),
    ((160, 60,240), (100, 20,160)),
    ((255,140, 20), (180, 80,  0)),
    ((40, 200,200), (  0,130,130)),
    ((60,120,255),  ( 20, 60,180)),
    ((230, 80,150), (160, 20, 90)),
]

class EnemyFish:
    def __init__(self, level):
        self.size = random.randint(12, 82)
        self.facing_right = random.choice([True, False])
        self.x = -130 if self.facing_right else WIDTH + 130
        self.y = random.randint(55, HEIGHT - 55)
        self.speed = random.uniform(1.8, 3.8) + level * 0.28
        self.tail  = random.uniform(0, 6.28)
        body, fin   = random.choice(FISH_PALETTES)
        self.body_col = body
        self.fin_col  = fin

    def update(self):
        self.x += self.speed * (1 if self.facing_right else -1)
        self.tail += 0.18

    def draw(self):
        draw_fish(screen, int(self.x), int(self.y),
                  self.size, self.body_col, self.facing_right, self.tail)

    def is_offscreen(self):
        return self.x < -260 or self.x > WIDTH + 260

    def get_rect(self):
        return pygame.Rect(self.x-self.size, self.y-self.size//2, self.size*2, self.size)


# ────────────────────────────────────────────────
class PowerUp:
    def __init__(self):
        self.x    = random.randint(60, WIDTH - 60)
        self.y    = random.randint(60, HEIGHT - 60)
        self.r    = 16
        self.type = random.choice(["shield", "speed"])
        self.t    = 0.0

    def draw(self):
        self.t += 0.08
        r = self.r + int(math.sin(self.t) * 3)
        color = CYAN if self.type == "shield" else YELLOW
        glow = pygame.Surface((r*4, r*4), pygame.SRCALPHA)
        pygame.draw.circle(glow, (*color, 60), (r*2, r*2), r+6)
        screen.blit(glow, (self.x - r*2, self.y - r*2))
        pygame.draw.circle(screen, color, (self.x, self.y), r)
        pygame.draw.circle(screen, WHITE, (self.x, self.y), r, 2)
        lbl = font_small.render("S" if self.type=="shield" else "!", True, DARK_BLUE)
        screen.blit(lbl, lbl.get_rect(center=(self.x, self.y)))

    def get_rect(self):
        return pygame.Rect(self.x-self.r, self.y-self.r, self.r*2, self.r*2)


# ────────────────────────────────────────────────
class BossShark:
    def __init__(self):
        self.x, self.y = float(WIDTH + 350), float(HEIGHT // 2)
        self.size  = 110
        self.speed = 1.8
        self.t     = 0.0

    def update(self):
        self.x -= self.speed
        self.t += 0.13

    def draw(self):
        draw_shark(screen, int(self.x), int(self.y), self.size, self.t)

    def is_offscreen(self): return self.x < -350

    def get_rect(self):
        return pygame.Rect(self.x-self.size, self.y-self.size//2, self.size*2, self.size)


# ────────────────────────────────────────────────
bg_cache = {}

def draw_background(level):
    if level < 3:    bg_type = 1
    elif level < 5:  bg_type = 2
    else:            bg_type = 3

    if bg_type not in bg_cache:
        bg_surf = pygame.Surface((WIDTH, HEIGHT))
        if bg_type == 1:   top, bot = (0,100,180),  (0, 30, 80)
        elif bg_type == 2: top, bot = (30,40,120),  (8, 8, 40)
        else:              top, bot = (70,15,100),  (18, 0, 40)
        
        for y in range(HEIGHT):
            t = y / HEIGHT
            r = int(top[0]*(1-t)+bot[0]*t)
            g = int(top[1]*(1-t)+bot[1]*t)
            b = int(top[2]*(1-t)+bot[2]*t)
            pygame.draw.line(bg_surf, (r,g,b), (0,y), (WIDTH,y))

        ray = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        for i in range(6):
            rx = int(WIDTH * (0.1 + i * 0.17))
            pts = [(rx-25,0),(rx+25,0),(rx+90,HEIGHT),(rx-90,HEIGHT)]
            pygame.draw.polygon(ray, (255,255,255,7), pts)
        bg_surf.blit(ray, (0,0))

        pygame.draw.rect(bg_surf, (20,50,15), (0, HEIGHT-22, WIDTH, 22))
        random.seed(42)
        for i in range(0, WIDTH, 35):
            h = random.randint(6,18)
            pygame.draw.ellipse(bg_surf, (15,90,35), (i, HEIGHT-22-h, 14, h+8))
            if random.random() < 0.3:
                pygame.draw.ellipse(bg_surf, (30,70,20),
                                    (i+random.randint(-8,8), HEIGHT-22-h-5, 20, 10))
        random.seed(None)
        bg_cache[bg_type] = bg_surf

    screen.blit(bg_cache[bg_type], (0, 0))


def draw_hud(player, level, high_score):
    screen.blit(font_med.render(f"Score: {player.score}", True, WHITE), (18, 18))
    screen.blit(font_med.render(f"Coins: {player.coins}", True, YELLOW), (18, 52))
    screen.blit(font_small.render(f"Best: {high_score}", True, (180,220,255)), (18, 84))
    lt = font_med.render(f"Level: {level}", True, WHITE)
    screen.blit(lt, (WIDTH - lt.get_width() - 18, 18))
    if player.shield:
        screen.blit(font_small.render(f"Shield {player.shield_timer//FPS+1}s", True, CYAN), (18, HEIGHT-45))
    if player.speed_boosted:
        screen.blit(font_small.render(f"Speed {player.speed_timer//FPS+1}s", True, YELLOW), (200, HEIGHT-45))

    # ── Progress bar to next level ──
    progress = (player.score % 10) / 10.0
    bar_x, bar_y, bar_w, bar_h = WIDTH//2 - 100, HEIGHT - 22, 200, 12
    pygame.draw.rect(screen, (30, 60, 90),   (bar_x, bar_y, bar_w, bar_h), border_radius=6)
    pygame.draw.rect(screen, CYAN,            (bar_x, bar_y, int(bar_w * progress), bar_h), border_radius=6)
    pygame.draw.rect(screen, WHITE,           (bar_x, bar_y, bar_w, bar_h), 1, border_radius=6)
    lbl = font_small.render(f"Next Level: {player.score % 10}/10", True, (180,220,255))
    screen.blit(lbl, lbl.get_rect(center=(WIDTH//2, bar_y - 10)))


start_bg_cache = None

def draw_start_screen():
    global start_bg_cache
    if start_bg_cache is None:
        start_bg_cache = pygame.Surface((WIDTH, HEIGHT))
        for y in range(HEIGHT):
            t = y/HEIGHT
            c = (int(0*(1-t)), int(60*(1-t)+20*t), int(160*(1-t)+80*t))
            pygame.draw.line(start_bg_cache, c, (0,y), (WIDTH,y))
    screen.blit(start_bg_cache, (0, 0))
    # Deco fish
    draw_fish(screen, 140, 180, 45, ORANGE,       True,  1.2, (180,80,0))
    draw_fish(screen, 730, 350, 60, PURPLE,       False, 0.8, (100,20,160))
    draw_fish(screen, 420, 460, 32, YELLOW,       True,  2.1, (180,140,0))
    draw_fish(screen, 600, 150, 25, CYAN,         False, 0.5, (0,130,130))
    draw_fish(screen, 250, 390, 50, (60,120,255), True,  1.7, (20,60,180))
    items = [
        (font_big,   "Fish Evolution",            CYAN,   165),
        (font_med,   "Eat smaller fish to grow!", WHITE,  270),
        (font_small, "Avoid bigger fish",          WHITE,  305),
        (font_small, "Your fish follows the mouse", YELLOW, 340),
        (font_small, "Press ENTER to Start",       YELLOW, 410),
    ]
    for fnt, txt, col, cy in items:
        s = fnt.render(txt, True, col)
        screen.blit(s, s.get_rect(center=(WIDTH//2, cy)))


def draw_game_over(player, high_score):
    ov = pygame.Surface((WIDTH, HEIGHT))
    ov.set_alpha(175)
    ov.fill((0,0,0))
    screen.blit(ov, (0,0))
    for fnt, txt, col, cy in [
        (font_big,   "GAME OVER",                   RED,   240),
        (font_med,   f"Final Score: {player.score}", WHITE, 318),
        (font_small, f"Best Score:  {high_score}",  YELLOW,362),
        (font_small, "Press ENTER to Restart",       YELLOW,405),
    ]:
        s = fnt.render(txt, True, col)
        screen.blit(s, s.get_rect(center=(WIDTH//2, cy)))


# ────────────────────────────────────────────────
def reset_game():
    global player, enemies, bubbles, powerups, boss
    global level, game_over, paused, spawn_timer, powerup_timer, boss_spawned
    global particles, floats
    player       = Fish()
    enemies      = []
    bubbles      = [Bubble() for _ in range(55)]
    powerups     = []
    boss         = None
    particles    = []
    floats       = []
    level        = 1
    game_over    = False
    paused       = False
    spawn_timer  = 0
    powerup_timer= 0
    boss_spawned = False


async def main():
    global high_score, boss_spawned, particles, floats, state, running, player, enemies, bubbles, powerups, boss, level, game_over, paused, spawn_timer, powerup_timer
    
    high_score   = 0
    boss_spawned = False
    particles    = []
    floats       = []
    reset_game()
    state   = "start"
    running = True

    while running:
        clock.tick(FPS)
        mx, my = pygame.mouse.get_pos()

        for event in pygame.event.get():
            if event.type == pygame.QUIT: running = False
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE: running = False
                if event.key == pygame.K_p and state == "playing":
                    paused = not paused
                if event.key == pygame.K_RETURN:
                    if state == "start":
                        state = "playing"
                    elif state == "playing" and game_over:
                        high_score = max(high_score, player.score)
                        reset_game()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if state == "start":
                    state = "playing"
                elif state == "playing" and game_over:
                    high_score = max(high_score, player.score)
                    reset_game()

        # ── Start screen ──────────────────────────────────────────────────────────
        if state == "start":
            draw_start_screen()
            # Player fish = mouse on start screen too
            draw_fish(screen, mx, my, 28, GREEN, True,
                      pygame.time.get_ticks()*0.01, (20,150,60))
            pygame.display.update()
            await asyncio.sleep(0)
            continue

        # ── Background ────────────────────────────────────────────────────────────
        draw_background(level)
        for b in bubbles: b.draw()

        if paused:
            s = font_big.render("PAUSED  —  P to continue", True, WHITE)
            screen.blit(s, s.get_rect(center=(WIDTH//2, HEIGHT//2)))
            pygame.display.update()
            await asyncio.sleep(0)
            continue

        # ── Logic ─────────────────────────────────────────────────────────────────
        if not game_over:
            for b in bubbles: b.update()

            player.move_to_mouse(mx, my)
            player.update_powerups()

            spawn_timer += 1
            if spawn_timer >= 38:
                enemies.append(EnemyFish(level))
                spawn_timer = 0

            powerup_timer += 1
            if powerup_timer >= FPS * 10:
                powerups.append(PowerUp())
                powerup_timer = 0

            for en in enemies[:]:
                en.update()
                if en.is_offscreen():
                    enemies.remove(en); continue
                if player.get_rect().colliderect(en.get_rect()):
                    if en.size < player.size:
                        player.size  = min(player.size + 2, 72)
                        player.score += 1
                        player.coins += 1
                        eat_sound.play()
                        # Eat particles
                        for _ in range(8):
                            particles.append(EatParticle(en.x, en.y))
                        floats.append(FloatText(en.x, en.y - 20, "+1", YELLOW))
                        enemies.remove(en)
                        if player.score % 10 == 0:
                            level += 1
                            level_sound.play()
                            floats.append(FloatText(WIDTH//2, HEIGHT//2 - 40,
                                                    f"LEVEL {level}!", CYAN))
                    elif not player.shield:
                        gameover_sound.play()
                        game_over = True

            for pu in powerups[:]:
                if player.get_rect().colliderect(pu.get_rect()):
                    if pu.type == "shield":
                        player.shield_timer = FPS * 5
                        floats.append(FloatText(pu.x, pu.y, "SHIELD!", CYAN))
                    else:
                        player.speed       = 18
                        player.speed_timer = FPS * 6
                        floats.append(FloatText(pu.x, pu.y, "SPEED!", YELLOW))
                    powerup_sound.play()
                    powerups.remove(pu)

            if level >= 5 and not boss_spawned:
                boss = BossShark(); boss_spawned = True

            if boss:
                boss.update()
                if boss.is_offscreen(): boss = None
                elif player.get_rect().colliderect(boss.get_rect()):
                    if player.size > boss.size:
                        player.score += 50; boss = None
                    elif not player.shield:
                        game_over = True

        # ── Draw ──────────────────────────────────────────────────────────────────
        for en in enemies: en.draw()
        for pu in powerups: pu.draw()
        if boss: boss.draw()

        # Particles & float texts
        for p in particles[:]:
            p.update(); p.draw()
            if not p.alive: particles.remove(p)
        for ft in floats[:]:
            ft.update(); ft.draw()
            if not ft.alive: floats.remove(ft)

        player.draw()
        draw_hud(player, level, high_score)
        if game_over:
            high_score = max(high_score, player.score)
            draw_game_over(player, high_score)

        pygame.display.update()
        await asyncio.sleep(0)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    asyncio.run(main())
